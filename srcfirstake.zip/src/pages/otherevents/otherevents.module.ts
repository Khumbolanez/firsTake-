import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { OthereventsPage } from './otherevents';

@NgModule({
  declarations: [
    OthereventsPage,
  ],
  imports: [
    IonicPageModule.forChild(OthereventsPage),
  ],
})
export class OthereventsPageModule {}
