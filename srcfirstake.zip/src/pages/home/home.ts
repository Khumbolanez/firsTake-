import { Component,NgZone } from '@angular/core';
import { NavController,Events } from 'ionic-angular';
import { RequestsProvider } from '../../providers/requests/requests';
import { UserProvider } from '../../providers/user/user';
import { EventsPage } from '../../pages/events/events';
import { VieweventPage } from '../../pages/viewevent/viewevent';
import { ProfilerPage } from '../../pages/profiler/profiler';
import { AngularFireAuth } from 'angularfire2/auth';
import firebase from 'firebase';

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
  
})
export class HomePage {
	numreq;
  myrequests;
  attendees = [];
  tempar = [];
  user;
	filteredevents = [];
  constructor(public navCtrl: NavController,public afireauth: AngularFireAuth,public userservice: UserProvider,public zone: NgZone,public events: Events,public reqservice: RequestsProvider) {
	
	this.userservice.getallevents().then((res: any) => {
		console.log("err las");
		this.filteredevents = res;
		this.tempar = res;
		
	})
	
  }
  
   ionViewWillEnter() {
    console.log('ionViewDidLoad Home');
	this.user = this.afireauth.auth.currentUser.uid;
	this.userservice.usermenu();
	this.reqservice.getmyrequests();
	
	
  }
  
  openprofile(){
	 // this.navCtrl.push(ProfilerPage);
  }
  
  joinevent(eventnamer){
	  this.userservice.addusertoevent(eventnamer).then((res: any) => {
		  alert("you have joined");
	  })
  }
  
  viewevent(key){
	  this.navCtrl.push(VieweventPage, {nameofevent: key.eventname,dateofevent: key.eventdate});
  }
 
  
	getmyrequests(){
		this.reqservice.getmyrequests();
		
	}
	ionViewDidLeave(){
		//this.events.unsubscribe('gotrequests');
	}

}
