import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { EditpicsPage } from './editpics';

@NgModule({
  declarations: [
    EditpicsPage,
  ],
  imports: [
    IonicPageModule.forChild(EditpicsPage),
  ],
})
export class EditpicsPageModule {}
