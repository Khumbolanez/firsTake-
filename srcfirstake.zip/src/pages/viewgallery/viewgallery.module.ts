import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ViewgalleryPage } from './viewgallery';

@NgModule({
  declarations: [
    ViewgalleryPage,
  ],
  imports: [
    IonicPageModule.forChild(ViewgalleryPage),
  ],
})
export class ViewgalleryPageModule {}
