import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { EditbioPage } from './editbio';

@NgModule({
  declarations: [
    EditbioPage,
  ],
  imports: [
    IonicPageModule.forChild(EditbioPage),
  ],
})
export class EditbioPageModule {}
