export interface connreg {
	sender: string;
	recipient: string;
}